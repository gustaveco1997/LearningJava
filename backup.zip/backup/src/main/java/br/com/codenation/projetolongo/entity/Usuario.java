package br.com.codenation.projetolongo.entity;

public class Usuario extends Pessoa {

    private String login;
    private String senha;
    private Empresa empresa;
    private long idEmpresa;
    private double salario;

    public Usuario() {

    }

    public Usuario(Long id, String nome, String documento, int idade, String login, String senha, Long idEmpresa, double salario) {
        this.id = id;
        this.name = nome;
        this.documento = documento;
        this.idade = idade;
        this.login = login;
        this.senha = senha;
        this.idEmpresa = idEmpresa;
        this.salario = salario;

    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public long getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(long idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
