package br.com.codenation.projetolongo;

import br.com.codenation.projetolongo.controller.AplicacaoController;
import br.com.codenation.projetolongo.entity.Empresa;
import br.com.codenation.projetolongo.entity.Usuario;
import br.com.codenation.projetolongo.exception.MyExceptions;
import br.com.codenation.projetolongo.service.AplicacaoService;
import br.com.codenation.projetolongo.service.FileStreamService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.BufferedReader;
import java.io.FileReader;

@SpringBootApplication
public class ProjetoLongoApplication {

    public static void main(String[] args) {
        Logger LOG = LoggerFactory.getLogger(AplicacaoService.class);

        SpringApplication.run(ProjetoLongoApplication.class, args);

        AplicacaoController controller = new AplicacaoController();
        controller.setDadosFromArquivos();

        controller.showFolhaPagamentoCadaEmpresa();
        controller.showMaiorSalarioCadaEmpresa();
        controller.showMediaSalarialCadaEmpresa();

        controller.showMediaIdade();
        controller.showUsuariosOdenadosIdadeCadaEmpresa();

        /*try {
            AplicacaoController controller = new AplicacaoController();

            Empresa empresa = new Empresa(1L, "Codenation", "12310290", 0);
            controller.insertEmpresa(empresa);

            empresa = new Empresa(2L, "Dti Digital", "92810", 10);
            controller.insertEmpresa(empresa);

            empresa = new Empresa(3L, "Sympla", "12380", 15);
            controller.insertEmpresa(empresa);

            Usuario usuario = new Usuario(1L, "Thiago",
                    "123456789", 31,
                    "oathiago", "codenation", 1L);
            controller.insertUsuario(usuario);

            usuario = new Usuario(2L, "Guilherme",
                    "13212", 30,
                    "guilherme", "codenation", 2L);
            controller.insertUsuario(usuario);

            usuario = new Usuario(3L, "Gustavo",
                    "21370192", 22,
                    "gustavo_henrique", "codenation", 3L);
            controller.insertUsuario(usuario);

            usuario = new Usuario(4L, "Leonardo",
                    "8981299", 34,
                    "leonardo", "codenarion", 1L);
            controller.insertUsuario(usuario);

            controller.findUsuariosEmpresas(usuario);


        } catch (MyExceptions e) {
            LOG.error(e.getMessage());
        }*/
    }
}

//DAO (Comandos de Banco)
//controller (entrada e exibição de dados)
//service (regra de negócio)
