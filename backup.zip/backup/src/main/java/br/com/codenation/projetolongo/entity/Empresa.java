package br.com.codenation.projetolongo.entity;

import java.util.ArrayList;
import java.util.List;

public class Empresa extends Pessoa {
    private int vagas;
    private List<Usuario> usuarios = new ArrayList<>();
    private String site;

    public Empresa() {

    }

    public Empresa(Long id, String nome, String documento, int vagas, String site) {
        this.id = id;
        this.name = nome;
        this.documento = documento;
        this.vagas = vagas;
        this.site = site;
        usuarios = new ArrayList<>();
    }


    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public int getVagas() {
        return vagas;
    }

    public void setVagas(int vagas) {
        this.vagas = vagas;
    }
}
