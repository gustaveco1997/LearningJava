package br.com.codenation.projetolongo.exception;

public class MyExceptions extends RuntimeException {

    public MyExceptions(String message) {

        super(message);
    }
}
